
#include <ArduinoJson.h>


#define holed 31
#define xoled 40

int course[xoled] = {0};

/////////////Pobranie danych z sieci////////
int getdata(){
  String j = "";
  if (WiFi.status() == WL_CONNECTED) { 
        
    HTTPClient http; 
    http.begin("http://api.noweenergie.org/index.php?VisuoBtc/price");  
    int httpCode = http.GET();             
    if (httpCode > 0) {                    
      j = http.getString();
	  Serial.println("dane:"+j);  
      
    }
    http.end();                           
  }
  return j.toInt();
}


///////////Wyszukiwanie minimum///////
int mini(int *t){
	//przyjecie jako minimum pierwszego elementu
	int min = t[0];
	//przegladanie wszystkich elementow
	for (int x=0; x<xoled; x++){
		//znaleziono nowe minimum
		if (t[x] < min && t[x] != 0){
			min = t[x];
		}
	}
	return min;
}

///////////Wyszukiwanie maksimum///////
int maxi(int *t){
	//przyjecie jako minimum pierwszego elementu
	int max = t[0];
	//przegladanie wszystkich elementow
	for (int x=0; x<xoled; x++){
		//znaleziono nowe maksimum
		if (t[x] > max){
			max = t[x];
		}
	}
	return max;
}


//////////obliczanie ile pikseli na jednostke///////
int pkty(float pkt, int min, int datay){
	//obliczenie punktu y i odbicie w osi x bo 0.0 jest u gory ekranu
	return int(holed-((datay-min) * pkt));
}

///////dodanie do tablicy//////////////
void addtoarray(int *a, int element){

	//przesuniecie o jeden do tylu
	for(int x=0; x<xoled-1; x++){
		a[x]=a[x+1];
	}
	//ostatni pusty
	a[xoled-1] = element;
}


/////////////czyszczenie danych////////////////////////
void clear_course(int *a){
  for(int x=0;x<xoled;x++){
    a[x]=0;
  }
}


//////////////Pokaz dane na ekranie////////////////////
void show_data(int *course){
	
	int price = getdata();
	addtoarray(course,price);


	int data_show[xoled];

	//wyszukanie minimow i maksimow
	float max = maxi(course);
	float min = mini(course);
	//obliczanie wysokosci 1 punktu na wykresie
	float pkt = (float)holed/max;

	Serial.println("max:"+String(max)+" min:"+String(min)+" pkt:"+String(pkt));

	//przygotowanie danych
	for (int x=0; x<xoled; x++){
		int y = pkty(pkt,min,course[x]);
		//u8g2.drawPixel(x,y);
		data_show[x] = y;
		Serial.println("kurs "+String(course[x])+" "+String(x)+" "+String(y));
	}

	//wyswietlenie danych
	u8g2.clearBuffer();
	for (int x=0; x<xoled-1; x++){
		u8g2.drawLine(x, data_show[x], x+1, data_show[x+1]);
	}
	u8g2.sendBuffer();


}
